
搭建node 项目步骤

mkdir src; // 创建放 TypeScript 源码的目录
touch src/cli.ts // CLI 命令入口文件
touch src/http-serve.ts // CLI 命令入口文件
mkdir lib; // 转译工具自动创建放 JavaScript 代码的目录
mkdir __tests__; // 单元测试文件目录

npm install typescript -D;
npm install ts-node -D;
npm install jest@24 -D;
npm install ts-jest@24 -D;
npm install @types/jest -D
在上述命令中，TypeScript、ts-node、Jest、Jest 类型声明是作为开发依赖 devDependencies 安装的。

{
  ...
  "bin": "lib/bin.js",
  "main": "lib/http-serve.js",
  "files": ["lib"],
  "scripts": {
    "build": "tsc -p tsconfig.prod.json",
    "start": "ts-node src/cli.ts",
    "test": "jest --all"
  },
  ...
}
bin 参数指定了 CLI 命令可执行文件指向的是转译后的 lib/cli.js；
main 参数则指定了模块的主文件是转译后的 lib/http-serve.js；
files指定了发布到 NPM 时包含的文件列表；
scripts build 命令则指定了使用 tsc 命令可以基于 tsconfig.prod.json 配置来转译 TypeScript 源码；
start 命令则指定了使用 ts-node 可以直接运行 TypeScript 源码；
test 命令则表示使用 Jest 可以执行所有单测

如此配置之后，我们就可以通过以下命令进行构建、开发、单测了。
npm start; // 开发
npm run build; // 构建
npm test; // 单测

接下来我们需要初始化 tsconfig 配置。

初始化 tsconfig
如果我们已经安装了全局的 TypeScript，那么就可以直接使用全局的 tsc 命令初始化。
当然，我们也可以直接使用当前模块目录下安装的 TypeScript 来初始化 tsconfig 配置。
这里我推荐全局安装 npx，可以更方便地调用安装在当前目录下的各种 CLI 工具，如下代码所示：
方法一：tsc --init; // 使用全局
方法二：npm install npx -g; // 安装 npx
npx tsc --init; // 或者使用 npx 调用当前目录下 node_modules 目录里安装的 tsc 版本

一般来说，我们需要将 declaration、sourceMap 这两个配置设置为 true，这样构建时就会生成类型声明和源码映射文件。
此时，即便模块在转译之后被其他项目引用，也能对 TypeScript 类型化和运行环境源码提供调试支持。
此外，一般我们会把 target 参数设置为 es5，module 参数设置为 commonjs，这样转译后模块的代码和格式就可以兼容较低版本的 Node.js 了。
然后，我们需要把 tsc 转译代码的目标目录 outDir 指定为 "./lib"。
除了构建行为相关的配置之外，我们还需要按照如下命令将 esModuleInterop 配置为 true，以便在类型检测层面兼容 CommonJS 和 ES 模块的引用关系，最终适用于 Node.js 开发的 tsconfig。
{
  "compilerOptions": {
    "target": "es5",
    "module": "commonjs",
    "declaration": true,
    "sourceMap": true,
    "outDir": "./lib",
    "rootDir": "./src",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true
  }
}

下面我们需要手动创建一个 tsconfig.prod.json，告诉 tsc 在转译源码时忽略 __tests__ 目录。
当然，我们也可以根据实际情况把其他文件、目录添加到 exclude 配置中，如下代码所示：
{
  "extends": "./tsconfig.json",
  "exclude": ["__tests__", "lib"]
}

注意：在实际项目中，我们并不经常使用 tsc --init 初始化 tsconfig。
出于统一和可控性考虑，我们可以将通用的 tsconfig 配置抽离为单独的 NPM 或直接使用第三方封装的配置，再通过 extends 参数进行复用，
比如可以安装https://www.npmjs.com/package/@tsconfig/node10等，如下代码所示：
npm install @tsconfig/node10 -D;

在当前模块的 tsconfig.json 中，我们只需保留路径相关的配置即可，其他配置可以继承自 node_modules 中安装的 tsconfig 模块，如下代码所示：
{
  "extends": "@tsconfig/node10",
  "compilerOptions": {
    "baseUrl": ".",
    "outDir": "./lib"
  }
}

接下来，我们需要使用 Node.js 内置的 http 模块和第三方 ecstatic、commander 模块实现 http-serve 静态文件服务器。

接口设计和编码实现
首先，我们需要安装以下相关依赖。
npm install @types/node -D; // 把 Node.js 内置模块类型声明文件作为开发依赖安装
npm install commander -S; //安装的是 CLI 需要用到的 commander
npm install ecstatic -S; //用来处理静态文件请求的 ecstatic

不幸的是，ecstatic 并不是一个对 TypeScript 友好的模块，因为它没有内置类型声明文件，也没有第三方贡献的 @types/ecstatic 类型声明模块。
因此，我们需要在项目根目录下新建一个 types.d.ts 用来补齐缺失的类型声明，如下代码所示：

注意：在业务实践中，如果碰到某个模块缺失类型声明文件，则会提示一个 ts(2307) 的错误，此时我们可以先尝试通过 npm i @types/模块名 -D 安装可能存在的第三方补齐类型声明。
如果找不到，再通过 declare module 手动补齐

接下来，我们在src/http-serve.ts中实现主逻辑。
首先，我们约定模块接收的参数及需要对外暴露的接口，如下示例：
export interface IHttpServerOptions {
  /** 静态文件目录，默认是当前目录 */
  root?: string;
  /** 缓存时间 */
  cache?: number;
}
/** 对外暴露的方法 */
export interface IHttpServer {
  /** 启动服务 */
  listen(port: number): void;
  /** 关闭服务 */
  close(): void;
}


下面我们一起看看如何使用 VS Code 调试源码。
使用 VS Code 调试
首先，我们需要给当前项目创建一个配置文件，具体操作方法为通过 VS Code 左侧或者顶部菜单 Run 选项添加或在 .vscode 目录中手动添加 launch.json，如图例所示：
Run-Add Configuration-node.js 
左侧菜单Run - Run and Debug - create a launch.json file -node.js
launch.json 文件配置
{
  "version": "0.2.0",
  "configurations": [
    {
      "type": "node",
      "request": "launch",
      "name": "http-serve/cli",
      "runtimeArgs": ["-r", "ts-node/register"],
      "args": ["${workspaceFolder}/src/cli.ts"]
    }
  ]
}

在上述配置中，我们唤起了 node 服务，并通过预载 ts-node/register 模块让 node 可以解析执行 TypeScript 文件（转译过程对使用者完全透明）
此时，我们可以在源文件中添加断点，并点击 Run 运行调试，如图例所示


单元测试
一般来说，运行 Node.js 端的模块转译单测代码使用的 tsconfig.test.json 配置和转译生成代码使用的 tsconfig.prod.json 配置完全一样，
因此我们可以直接将 tsconfig.prod.json 复制到 tsconfig.test.json。
详见test单测文件 执行npm run test
node需使用v18  nvm use v18

注意：源码中使用的路径别名，比如用“@/module”代替“src/sub-directory/module”，这样可以缩短引用路径，这就需要我们调整相应的配置。

处理路径别名
首先，我们需要在 tsconfig.json 中添加如下所示 paths 配置，这样 TypeScript 就可以解析别名模块。
{
 "compilerOptions": {
    ...,
    "baseUrl": "./",
    "paths": {
      "@/*": ["src/sub-directory/*"]
    },   
    ...
  }
}
注意：需要显式设置 baseUrl，不然会提示一个无法解析相对路径的错误。
接下来我们在 jest.config.js 中通过如下代码配置相应的规则，告知 Jest 如何解析别名模块。
module.exports = {
  ...,
  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/src/sub-directory/$1'
  },
  ...
}


因为 tsc 在转译代码的时候不会把别名替换成真实的路径，所以我们引入额外的工具处理别名。
此时我们可以按照如下命令安装 tsc-alias 和 tsconfig-paths 分别供 tsc 和 ts-node 处理别名。

最后，我们需要修改 package.json scripts 配置，如下代码所示：
{
  ...,
  "scripts": {
    "build": "tsc -p tsconfig.prod.json && tsc-alias -p tsconfig.prod.json",
    "start": "node -r tsconfig-paths/register -r ts-node/register src/cli.ts",
    ...
  },
  ...
}

tsc 构建转译之后，build 命令会使用 tsc-alias 将别名替换成相对路径。
在载入 ts-node/register 模块之前，start会预载 tsconfig-paths/register，这样 ts-node 也可以解析别名了。

小结
上就是使用 TypeScript 开发一个简单静态文件服务 NPM 模块的全过程，我们充分利用了 TypeScript 生态中的各种工具和特性。
关于如何开发基于 TypeScript 的 Node.js 模块和服务，我在下面也总结了一些建议。
* export 导出模块内的所有必要的类型定义，可以帮助我们减少 ts(4023) 错误。
* 我们可以开启 importHelpers 配置，公用 tslib 替代内联 import 等相关 polyfill 代码，从而大大减小生成代码的体积，配置示例如下：
{
  "extends": "./tsconfig.json",
  "compilerOptions": {
    "importHelpers": true
  },
  "exclude": ["__tests__", "lib"]
}
配置 importHelpers 为 true，此时一定要把 tslib 加入模块依赖中：
npm install tslib -S; // 安装 tslib 依赖
* 确保 tsconfig.test.json 和 tsconfig.prod.json 中代码转译相关的配置尽可能一致，避免逻辑虽然通过了单测，但是构建之后运行提示错误。
* 慎用 import * as ModuleName，因为较低版本的 tslib 实现的 __importStar 补丁有 bug。如果模块 export 是类的实例，经 __importStar 处理后，会造成实例方法丢失。另外一个建议是避免直接 export 一个类的实例，如下代码所示：* 
xports = module.exports = new Command(); // bad
* 推荐使用完全支持 TypeScript 的 NestJS 框架开发企业级 Node.js 服务端应用。

